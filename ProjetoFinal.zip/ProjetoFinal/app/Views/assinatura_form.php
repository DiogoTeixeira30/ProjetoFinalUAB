<form method="post" action="/assinatura/processarAssinatura">
  <label for="telemovel">Número de Telemóvel:</label>
  <input type="text" name="telemovel" id="telemovel" required>

  <label for="pin">PIN CMD:</label>
  <input type="password" name="pin" id="pin" required>

  <button type="submit">Assinar Documento</button>
</form>
